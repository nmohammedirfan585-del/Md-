# MD — Android AI voice assistant

`android/` Kotlin + Jetpack Compose app · `backend/` Node server (AI proxy + PPTX generator).

## 1. Run the backend
```
cd backend && npm install && cp .env.example .env
# optional: put a key in .env (Groq/OpenRouter free tiers have rate limits; Ollama is fully local/free)
export $(grep -v '^#' .env | xargs) && npm start
```
No key = local mode: built-in commands work, presentations use a template outline you can edit.
Phone and computer must be on the same Wi-Fi; in the app's Settings set Backend URL to `http://<computer-LAN-IP>:3000`
(emulator: `http://10.0.2.2:3000`). For internet use, deploy behind HTTPS (e.g. Replit) and set APP_TOKEN.
The API key lives only on the server, never in the APK.

## 2. Build a debug APK
- **Android Studio (easiest):** open `android/`, wait for Gradle sync, Build > Build APK(s). Output: `app/build/outputs/apk/debug/app-debug.apk`.
- **Free, no install:** push this folder to GitHub; the included workflow builds the APK (Actions tab > artifact `MD-debug-apk`).
- Replit usually can't run the Android SDK; use the options above.

## 3. Install
Copy the APK to the phone, open it, allow "Install unknown apps" for your file manager/browser when prompted.

## 4. Permissions
- Microphone: asked on first mic tap.
- Accessibility (only needed for **Back**): Settings > Accessibility > MD > turn on. MD only presses Home/Back; it does not read the screen. Home works without it.
- Media controls (pause/play/next) need no permission but only affect apps exposing a media session.

## Limits (by Android design)
- Always-on wake word is **not** implemented: Android restricts background microphone use and it drains battery. Use the mic button.
- "Play a song" opens YouTube search results; guaranteed autoplay needs the YouTube Data API plus a selected video ID.
- Sensitive actions (calls, SMS, payments) are intentionally blocked. Presentation creation asks for confirmation.
- Cleartext HTTP is enabled for LAN testing; use HTTPS in production.
